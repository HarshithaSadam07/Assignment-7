import React from 'react';
function App() { return <div>BookMyShow App</div>; }
export default App;